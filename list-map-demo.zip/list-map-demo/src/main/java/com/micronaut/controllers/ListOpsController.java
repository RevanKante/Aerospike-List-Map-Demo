//package com.micronaut.controllers;
//
//import com.aerospike.client.Record;
//import com.micronaut.services.ListService;
//import io.micronaut.http.annotation.Controller;
//import io.micronaut.http.annotation.Get;
//import io.micronaut.http.annotation.PathVariable;
//import jakarta.inject.Inject;
//
//import java.util.List;
//
//@Controller("/listops")
//public class ListOpsController {
//    @Inject
//    ListService listService;
//
//    @Get("/add")
//    public String add() {
//        return listService.addList();
//    }
//
//    @Get("/get/{key}")
//    public List<String> get(@PathVariable int key) {
//        return listService.getList(key);
//    }
//
//    @Get("/insert1/{fruit}/{key}")
//    public String insert(@PathVariable String fruit,@PathVariable int key) {
//        return listService.insertIntoList(fruit, key);
//    }
//}
