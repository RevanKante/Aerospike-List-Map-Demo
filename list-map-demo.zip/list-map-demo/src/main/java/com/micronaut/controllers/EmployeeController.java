package com.micronaut.controllers;

import com.micronaut.entities.Employee;
import com.micronaut.services.EmployeeService;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.Post;
import jakarta.inject.Inject;

import java.util.List;

@Controller("/employee")
public class EmployeeController {

    @Inject
    EmployeeService employeeService;

    @Post("/add")
    public String addEmployee(@Body Employee employee) {
       return employeeService.addEmployee(employee);
    }

    @Get("/getall")
    public List<Employee> getEmployees() {
        return employeeService.getEmployees();
    }
}
