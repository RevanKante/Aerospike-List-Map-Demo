package com.micronaut.repositories;

import com.micronaut.configuration.AeroMapperConfiguration;
import com.micronaut.entities.Employee;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

import java.util.List;
import java.util.Random;

@Singleton
public class EmployeeRepository {

    @Inject
    AeroMapperConfiguration mapper;

    public String addEmployee(Employee employee) {
        String result;
        try {
            Random random = new Random();
            Employee newEmployee = new Employee();
            newEmployee.setId(random.nextInt(1000));
            newEmployee.setAge(employee.getAge());
            newEmployee.setName(employee.getName());
            newEmployee.setContactNum(employee.getContactNum());
            newEmployee.setEmail(employee.getEmail());
            newEmployee.setSalary(employee.getSalary());
            newEmployee.setJoiningDate(employee.getJoiningDate());
            newEmployee.setDepartment(employee.getDepartment());

            mapper.getMapper().save(newEmployee);
            result = "Employee created successfully id is "+newEmployee.getId();
        }
        catch (Exception e) {
            e.printStackTrace();
            result = "Failed to register";
        }
        return  result;
    }

    public List<Employee> getEmployees() {
        return mapper.getMapper().scan(Employee.class);
    }
}
