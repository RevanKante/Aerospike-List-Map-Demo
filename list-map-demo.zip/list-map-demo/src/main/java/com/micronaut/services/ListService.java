//package com.micronaut.services;
//
//import com.aerospike.client.*;
//import com.aerospike.client.cdt.ListOperation;
//import com.aerospike.client.policy.Policy;
//import com.aerospike.client.policy.WritePolicy;
//import com.aerospike.client.query.Filter;
//import com.aerospike.client.query.RecordSet;
//import com.aerospike.client.query.Statement;
//import com.aerospike.client.Record;
//import com.micronaut.configuration.AeroMapperConfiguration;
//import jakarta.inject.Inject;
//import jakarta.inject.Singleton;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Random;
//
//@Singleton
//public class ListService {
//
//    @Inject
//    AeroMapperConfiguration configuration;
//    AerospikeClient client = configuration.getClient();
//
//    public String addList() {
//        String message = "";
//        try {
//            Random random = new Random();
//            List<String> listStr = new ArrayList<String>();
//            listStr.add("Grapes");
//            listStr.add("Lychee");
//            listStr.add("Cherry");
//            listStr.add("Apple");
//
//            int listKey = random.nextInt(10000);
//            Key key = new Key("test","listset",listKey);
//
//            Bin bin1 = new Bin("index", listKey);
//            Bin bin2 = new Bin("list", listStr);
//
//            WritePolicy policy = new WritePolicy();
//            policy.sendKey = true;
//
//            client.put(policy, key, bin1, bin2);
//            message = "List added successfully";
//        }
//        catch (Exception e) {
//            message = e.getMessage();
//        }
//        return "List added successfully";
//    }
//
//    public List<String> getList(int key) {
//        Key newKey = new Key("test", "listset",key);
//        Record record = configuration.getClient().get(null, newKey);
//        return (List<String>)record.getValue("list");
//    }
//
//    public Record getRecordByKey(int key) {
//        try {
//            List<String> records = new ArrayList<>();
//
//            Policy policy = new Policy();
//            policy.sendKey=true;
//
//            Statement statement = new Statement();
//            statement.setNamespace("test");
//            statement.setSetName("listset");
//
//            statement.setFilter(Filter.equal("index", key));
//
//            RecordSet record = client.query(null,statement);
//
//            if (record.next()) {
//                System.out.println(record.getKey());
//                System.out.println(record.getRecord());
//                return record.getRecord();
//            }
//            else {
//                return  record.getRecord();
//            }
//        }
//        catch (Exception e) {
//            return null;
//        }
//    }
//
//    public String insertIntoList(String fruit, int key1) {
//        String result = "";
//        try {
//            Key newKey = new Key("test","listset",key1);
//
//            Record origRecord = client.get(null, newKey);
//
//            client.operate(client.writePolicyDefault, newKey,
//                    ListOperation.insert("list", -1, Value.get(fruit))
//            );
//            result = "Inserted successfully";
//        }
//        catch (Exception e) {
//            System.out.println(e.getMessage());
//            result = "Insertion failed";
//        }
//        return result;
//    }
//}
