package com.micronaut.services;

import com.micronaut.entities.Employee;
import com.micronaut.repositories.EmployeeRepository;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

import java.util.List;

@Singleton
public class EmployeeService {

    @Inject
    EmployeeRepository repository;
    public String addEmployee(Employee employee) {
        return repository.addEmployee(employee);
    }

    public List<Employee> getEmployees() {
        return repository.getEmployees();
    }
}
